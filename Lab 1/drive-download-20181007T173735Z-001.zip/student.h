#include <string>
using namespace std;
#ifndef STUDENT_H
#define STUDENT_H

struct student
   {
       string fname;
       string lname;
       string stuID;
   };
#endif
