#include <string>
using namespace std;
#ifndef COURSE_H
#define COURSE_H
struct course
   {
       string CourseName;
       string CourseID;
       int numberOfCredits;
   };
#endif
